﻿using System.Collections;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace POE_MpsheST10365000
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private ArrayList recipes;
        private List<string[]> ingredientsList = new List<string[]>();
        private List<string[]> quantityList = new List<string[]>();
        private List<string[]> unitOfMeasurementList = new List<string[]>();
        private List<string[]> caloriesList = new List<string[]>();
        private List<string[]> foodGroupList = new List<string[]>();
        private List<string[][]> stepsList = new List<string[][]>();
        private List<string[]> originalQuantitiesList = new List<string[]>();

        //public event CaloriesExceededEventHandler CaloriesExceeded;
        public delegate void CaloriesExceededEventHandler(string recipeName);

        public MainWindow()
        {
            InitializeComponent();
            recipes = new ArrayList();

            FoodGroupFilterComboBox.Items.Add("Carbohydrates");
            FoodGroupFilterComboBox.Items.Add("Vegetable");
            FoodGroupFilterComboBox.Items.Add("Fruit");
            FoodGroupFilterComboBox.Items.Add("Grain");
            FoodGroupFilterComboBox.Items.Add("Oils and Solid Fats");
            FoodGroupFilterComboBox.Items.Add("Protein Foods");
            FoodGroupFilterComboBox.Items.Add("Added sugar");
            FoodGroupFilterComboBox.Items.Add("Diary");
            FoodGroupFilterComboBox.Items.Add("Beverages");
        }


        private void GetStartedButton_Click(object sender, RoutedEventArgs e)
        {
            WelcomeGrid.Visibility = Visibility.Collapsed;
            MenuGrid.Visibility = Visibility.Visible;
        }

        private void NewRecipe_Click(object sender, RoutedEventArgs e)
        {
            MenuGrid.Visibility = Visibility.Collapsed;
            NewRecipeGrid.Visibility = Visibility.Visible;
        }
        private void AddRecipeDetails_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = NameTextBox.Text.Trim();
            if (int.TryParse(NumberOfIngredientsTextBox.Text.Trim(), out int numberOfIngredients))
            {
                string[] ingredients = new string[numberOfIngredients];
                string[] quantities = new string[numberOfIngredients];
                string[] unitsOfMeasurement = new string[numberOfIngredients];
                string[][] steps = new string[numberOfIngredients][];
                string[] originalQuantities = new string[numberOfIngredients];
                string[] calories = new string[numberOfIngredients];
                string[] foodGroups = new string[numberOfIngredients];

                for (int i = 0; i < numberOfIngredients; i++)
                {
                    TextBox ingredientNameBox = (TextBox)IngredientsPanel.FindName($"IngredientTextBox_Name_{i + 1}");
                    TextBox ingredientQuantityBox = (TextBox)IngredientsPanel.FindName($"IngredientTextBox_Quantity_{i + 1}");
                    TextBox ingredientUnitBox = (TextBox)IngredientsPanel.FindName($"IngredientTextBox_Unit_{i + 1}");
                    TextBox ingredientCaloriesBox = (TextBox)IngredientsPanel.FindName($"IngredientTextBox_Calories_{i + 1}");
                    TextBox ingredientFoodGroupBox = (TextBox)IngredientsPanel.FindName($"IngredientTextBox_FoodGroup_{i + 1}");

                    if (ingredientNameBox != null && ingredientQuantityBox != null && ingredientUnitBox != null && ingredientCaloriesBox != null && ingredientFoodGroupBox != null)
                    {
                        ingredients[i] = ingredientNameBox.Text.Trim();
                        quantities[i] = ingredientQuantityBox.Text.Trim();
                        unitsOfMeasurement[i] = ingredientUnitBox.Text.Trim();
                        calories[i] = ingredientCaloriesBox.Text.Trim();
                        foodGroups[i] = ingredientFoodGroupBox.Text.Trim();

                        steps[i] = CaptureStepsForIngredient($"Ingredient {i + 1}");

                        originalQuantities[i] = quantities[i];
                    }
                }

                ingredientsList.Add(ingredients);
                quantityList.Add(quantities);
                unitOfMeasurementList.Add(unitsOfMeasurement);
                caloriesList.Add(calories);
                foodGroupList.Add(foodGroups);
                stepsList.Add(steps);
                originalQuantitiesList.Add(originalQuantities);

                string recipeDetails = $"Recipe Name: {recipeName}\nIngredients:\n";
                for (int i = 0; i < numberOfIngredients; i++)
                {
                    recipeDetails += $"{ingredients[i]}: {quantities[i]} {unitsOfMeasurement[i]}, {calories[i]} calories, {foodGroups[i]}\n";
                    recipeDetails += "Steps:\n";
                    for (int j = 0; j < steps[i].Length; j++)
                    {
                        recipeDetails += $"{j + 1}. {steps[i][j]}\n";
                    }
                    recipeDetails += "\n";
                }

                recipes.Add(recipeDetails);

                // Calculate total calories and check if it exceeds 300
                int totalCalories = CalculateTotalCalories(calories);
                if (totalCalories > 300)
                {
                    MessageBox.Show($"Warning: The total calories for this recipe exceed 300 calories (Total: {totalCalories} calories).", "Calorie Alert", MessageBoxButton.OK, MessageBoxImage.Warning);
                }


                NameTextBox.Clear();
                NumberOfIngredientsTextBox.Clear();
                IngredientsPanel.Children.Clear();

                NewRecipeGrid.Visibility = Visibility.Collapsed;
                MenuGrid.Visibility = Visibility.Visible;
            }
            else
            {
                MessageBox.Show("Please enter a valid number of ingredients.");
            }
        }
        private void BackToMenu_Click(object sender, RoutedEventArgs e)
        {
            DisplayRecipesGrid.Visibility = Visibility.Collapsed;
            MenuGrid.Visibility = Visibility.Visible;
        }

        private void GenerateIngredientsFields_Click(object sender, RoutedEventArgs e)
        {
            IngredientsPanel.Children.Clear();

            if (int.TryParse(NumberOfIngredientsTextBox.Text.Trim(), out int numIngredients))
            {
                for (int i = 0; i < numIngredients; i++)
                {
                    AddIngredientField(i + 1);
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number of ingredients.");
            }
        }

        private int CalculateTotalCalories(string[] calories)
        {
            return calories.Select(cal => int.TryParse(cal, out int calVal) ? calVal : 0).Sum();
        }

        private void AddIngredientField(int index)
        {
            TextBlock ingredientLabel = new TextBlock
            {
                Text = $"Ingredient {index}:",
                Margin = new Thickness(0, 5, 0, 5)
            };

            TextBox ingredientNameBox = CreateTextBox($"IngredientTextBox_Name_{index}");
            TextBox ingredientQuantityBox = CreateTextBox($"IngredientTextBox_Quantity_{index}");
            TextBox ingredientUnitBox = CreateTextBox($"IngredientTextBox_Unit_{index}");
            TextBox ingredientCaloriesBox = CreateTextBox($"IngredientTextBox_Calories_{index}");
            TextBox ingredientFoodGroupBox = CreateTextBox($"IngredientTextBox_FoodGroup_{index}");

            IngredientsPanel.Children.Add(ingredientLabel);
            IngredientsPanel.Children.Add(CreateLabel("Name:"));
            IngredientsPanel.Children.Add(ingredientNameBox);
            IngredientsPanel.Children.Add(CreateLabel("Quantity:"));
            IngredientsPanel.Children.Add(ingredientQuantityBox);
            IngredientsPanel.Children.Add(CreateLabel("Unit of Measurement:"));
            IngredientsPanel.Children.Add(ingredientUnitBox);
            IngredientsPanel.Children.Add(CreateLabel("Calories:"));
            IngredientsPanel.Children.Add(ingredientCaloriesBox);
            IngredientsPanel.Children.Add(CreateLabel("Food Group:"));
            IngredientsPanel.Children.Add(ingredientFoodGroupBox);
        }

        private TextBox CreateTextBox(string name)
        {
            TextBox textBox = new TextBox
            {
                Name = name,
                Margin = new Thickness(0, 0, 0, 10)
            };

            // Check if the name already exists, if yes, generate a unique name
            int index = 1;
            while (IngredientsPanel.FindName(textBox.Name) != null)
            {
                textBox.Name = $"{name}_{index}";
                index++;
            }

            RegisterName(textBox.Name, textBox);
            return textBox;
        }

        private TextBlock CreateLabel(string text)
        {
            return new TextBlock
            {
                Text = text,
                Margin = new Thickness(0, 5, 0, 5)
            };
        }

        private string[] CaptureStepsForIngredient(string ingredientName)
        {
            string input = Microsoft.VisualBasic.Interaction.InputBox($"Enter the number of steps for {ingredientName}:", "Number of Steps");
            if (int.TryParse(input, out int numberOfSteps))
            {
                string[] steps = new string[numberOfSteps];
                for (int i = 0; i < numberOfSteps; i++)
                {
                    steps[i] = Microsoft.VisualBasic.Interaction.InputBox($"Enter step {i + 1} for {ingredientName}:", $"Step {i + 1}");
                }
                return steps;
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter a valid number of steps.");
                return CaptureStepsForIngredient(ingredientName);
            }

        }
        private void DisplayRecipe_Click(object sender, RoutedEventArgs e)
        {
            MenuGrid.Visibility = Visibility.Collapsed;
            DisplayRecipesGrid.Visibility = Visibility.Visible;
            RecipeListTextBlock.Text = string.Join("\n\n", recipes.ToArray());
        }

        private void SearchRecipe_Click(object sender, RoutedEventArgs e)
        {
            // Create a new window or dialog to get user input for recipe search
            string recipeName = Microsoft.VisualBasic.Interaction.InputBox("Enter the name of the recipe to search:", "Search Recipe");

            // Flag to track if the recipe is found
            bool found = false;

            // Loop through all recipes to find a match
            for (int i = 0; i < recipes.Count; i++)
            {
                // Extract the recipe name from the stored recipe details
                string storedRecipe = recipes[i] as string;
                string[] lines = storedRecipe.Split('\n');
                string storedRecipeName = lines[0].Replace("Recipe Name: ", "").Trim();

                // Check if the current recipe name matches the input name
                if (storedRecipeName.Equals(recipeName, StringComparison.OrdinalIgnoreCase))
                {
                    // If a matching recipe is found, prepare the details for display
                    string recipeDetails = $"Recipe: {storedRecipeName}\nIngredients:\n";

                    // Loop through each ingredient of the current recipe
                    for (int j = 0; j < ingredientsList[i].Length; j++)
                    {
                        // Append ingredient details to the recipe details string
                        recipeDetails += $"- {ingredientsList[i][j]}\n";
                        recipeDetails += $"  Quantity: {quantityList[i][j]}\n";
                        recipeDetails += $"  Unit of Measurement: {unitOfMeasurementList[i][j]}\n";
                        recipeDetails += $"  Calories: {caloriesList[i][j]}\n";
                    }

                    // Append steps to the recipe details string
                    recipeDetails += "Steps:\n";
                    for (int j = 0; j < stepsList[i].Length; j++)
                    {
                        recipeDetails += $"{j + 1}. {string.Join(", ", stepsList[i][j])}\n";
                    }

                    // Display the recipe details in a MessageBox
                    MessageBox.Show(recipeDetails, "Recipe Found");

                    found = true; // Set flag to true since recipe is found
                    break;
                }
            }

            // If no matching recipe is found, display an error message
            if (!found)
            {
                MessageBox.Show("Recipe not found.", "Search Result");
            }
        }


        private void ScaleRecipe_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Prompt user to enter the scaling factor (0.5 for half, 2 for double, 3 for triple)
                string input = Microsoft.VisualBasic.Interaction.InputBox("Enter the scaling factor (0.5 for half, 2 for double, 3 for triple):", "Scale Recipe");

                if (double.TryParse(input, out double factor) && (factor == 0.5 || factor == 2 || factor == 3))
                {
                    StringBuilder scaledRecipes = new StringBuilder();

                    // Scale each ingredient quantity
                    for (int i = 0; i < recipes.Count; i++)
                    {
                        string[] originalQuantities = originalQuantitiesList[i];
                        string[] scaledQuantities = new string[originalQuantities.Length];
                        string[] ingredients = ingredientsList[i];

                        scaledRecipes.AppendLine($"Recipe: {recipes[i]}");
                        scaledRecipes.AppendLine("Ingredients:");

                        // Scale the quantities for the current recipe
                        for (int j = 0; j < originalQuantities.Length; j++)
                        {
                            // Convert quantity to double
                            if (double.TryParse(originalQuantities[j], out double originalQuantity))
                            {
                                // Scale the quantity by the factor
                                double scaledQuantity = originalQuantity * factor;
                                scaledQuantities[j] = scaledQuantity.ToString();
                                scaledRecipes.AppendLine($"- {ingredients[j]}: {scaledQuantity} {unitOfMeasurementList[i][j]} ({caloriesList[i][j]} calories)");
                            }
                            else
                            {
                                // Handle invalid quantity format
                                MessageBox.Show($"Invalid quantity format for ingredient {ingredients[j]}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }

                        // Update the quantityList with scaled quantities
                        quantityList[i] = scaledQuantities;

                        scaledRecipes.AppendLine("Steps:");
                        for (int k = 0; k < stepsList[i].Length; k++)
                        {
                            scaledRecipes.AppendLine($"{k + 1}. {string.Join(", ", stepsList[i][k])}");
                        }

                        scaledRecipes.AppendLine("==================================================");
                        scaledRecipes.AppendLine();
                    }

                    // Show success message with scaled recipes
                    MessageBox.Show($"Recipe scaled successfully!\n\n{scaledRecipes.ToString()}", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Invalid scaling factor. Please enter 0.5, 2, or 3.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Oops! Something went wrong while scaling the recipe.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FoodGroupFilterComboBox_SelectionChanged(object sender, RoutedEventArgs e)
        {
            if (FoodGroupFilterComboBox.SelectedItem != null)
            {

                string SelectedOption = (FoodGroupFilterComboBox.SelectedItem as ComboBoxItem)?.Content.ToString() ?? FoodGroupFilterComboBox.SelectedItem.ToString();
                MessageBox.Show($"You selecte: {SelectedOption}");

            }

        }


        private void ResetData_Click(object sender, RoutedEventArgs e)
        {

            for (int i = 0; i < recipes.Count; i++)
            {
                quantityList[i] = originalQuantitiesList[i]; // Reset the quantities to original values
            }
            MessageBox.Show("Recipe quantities have been reset to their original values.", "Reset Successful", MessageBoxButton.OK, MessageBoxImage.Information);
        }


        private void ApplyFilters_Click(object sender, RoutedEventArgs e)
        {
            string ingredientFilter = IngredientFilterTextBox.Text.Trim();
            string foodGroupFilter = FoodGroupFilterComboBox.SelectedItem as string;
            int maxCaloriesFilter = 0;
            int.TryParse(MaxCaloriesFilterTextBox.Text.Trim(), out maxCaloriesFilter);

            StringBuilder filteredRecipes = new StringBuilder();

            // Loop through all recipes to apply filters
            foreach (string recipe in recipes)
            {
                string[] lines = recipe.Split('\n');
                string recipeName = lines[0].Replace("Recipe Name: ", "").Trim();

                // Check if recipe matches ingredient filter
                if (!string.IsNullOrEmpty(ingredientFilter) && !lines.Any(line => line.Contains(ingredientFilter, StringComparison.OrdinalIgnoreCase)))
                {
                    continue; // Skip this recipe if it doesn't contain the specified ingredient
                }

                // Check if recipe matches food group filter
                if (!string.IsNullOrEmpty(foodGroupFilter) && !lines.Any(line => line.Contains(foodGroupFilter, StringComparison.OrdinalIgnoreCase)))
                {
                    continue; // Skip this recipe if it doesn't belong to the specified food group
                }

                // Calculate total calories for the recipe
                int totalCalories = lines.Where(line => line.Contains("Calories:")).Sum(line => int.Parse(line.Split(':')[1].Trim()));

                // Check if recipe matches max calories filter
                if (maxCaloriesFilter > 0 && totalCalories > maxCaloriesFilter)
                {
                    continue; // Skip this recipe if it exceeds the maximum calories
                }

                // Add the recipe to the filtered list
                filteredRecipes.AppendLine(recipe);
            }

            // Display the filtered recipes
            MessageBox.Show(filteredRecipes.ToString(), "Filtered Recipes");
        }


        private void ClearData_Click(object sender, RoutedEventArgs e)
        {
            recipes.Clear();
            ingredientsList.Clear();
            quantityList.Clear();
            unitOfMeasurementList.Clear();
            caloriesList.Clear();
            foodGroupList.Clear();
            stepsList.Clear();
            originalQuantitiesList.Clear();
            MessageBox.Show("All data has been cleared.");
        }


        private void Exit_Clicked(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void FoodGroupFilterComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}